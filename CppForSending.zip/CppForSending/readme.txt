


Compile command:
g++ -Wall -std=c++23 -o main ./main.cc ./controller/*.cc ./powerstring/*.cc
Run command:
./main.exe    (of course)