#include "controller/controller.h"

int main()
{
    return Controller{}.run();
}